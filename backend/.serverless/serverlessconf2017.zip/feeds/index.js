'use strict';

module.exports = {
  create: require('./create'),
  delete: require('./delete'),
  list: require('./list'),
  get: require('./get'),
  update: require('./update'),
};
